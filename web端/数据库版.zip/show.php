<!DOCTYPE html>
<html>
<head><link rel="stylesheet" type="text/css" href="table.css"/></head>
<body>
<h1>list show</h1>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);   //解决报警级别
// $fh=fopen("1.csv","r");
// while(!feof($fh))
// {
// $arr=fgetcsv($fh);
// if($arr==NULL)
//     break;
// foreach($arr as $key=>$value)
// {echo $value,"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";}
// echo "<br>";
// }
// fclose($fh);


$one=mysql_connect("localhost","root","1234");
if(!$one){
    die('数据库连接失败'.mysql_error());
}
mysql_select_db("test",$one);    //挑选你的数据库
$result=mysql_query("select * from user");

// 输出表格及th
echo "<table  border='2' width='300'>
                <tr>
                <th>username</th><th>pass</th>
                <th>licensetype</th>
                <th>keynum</th>
                </tr>";
// 遍历数据表中的内容
while($row=mysql_fetch_array($result)){
    echo "<tr>";
    // userid === 用户id 与数据表中的id名称对应
    echo "<td>".$row['username']."</td>";
    // username === 用户名称 与数据表中的username名称对应
    echo "<td>".$row['password']."</td>";
    // password === 用户密码 与数据表中的密码对应
    echo "<td>".$row['licensetype']."</td>";
    
    echo "<td>".$row['keynum']."</td>";
    echo "</tr>";
}
echo "</table>";

$result=mysql_query("select * from license");
echo "<table border='2' width='300'>
                <tr>
                <th>pid</th><th>keynum</th>
                </tr>";
while($row=mysql_fetch_array($result)){
    echo "<tr>";
    // userid === 用户id 与数据表中的id名称对应
    echo "<td>".$row['pid']."</td>";
    // username === 用户名称 与数据表中的username名称对应
    echo "<td>".$row['keynum']."</td>";
    echo "</tr>";
}
echo "</table>";
?>

</body>
</html>